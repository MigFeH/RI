Miguel Fernández Huerta
UO287577
Modelo 1

Consideraciones a la hora de evaluar:
Si veis que hay gateways o clases en service de más como 
PaymentMeanGateway, ClientGateway y clases que no corresponden 
con el modelo es porque empecé implementando el settleInvoice 
y cuando estaba acabándolo me dí cuenta de que no había que 
hacerlo, terminé eliminando tanto el settleInvoice del paquete
ui como el de service, pero no recordaba las clases que tuve
que implementar para su desarrollo y como tenía miedo a borrar
algo que sí usé para implementar el modelo 1 pues preferí 
dejarlas.

Había clases del otro modelo que yo no tenía que implementar y 
como se exigía que no hubieran errores ni warnings, decidí 
crear las clases necesarias pero vacías con el fin de eliminar
los errores y warnings por falta de implementación de algunas 
clases que no pertenecían a mi modelo.

Es posible que salte el warning:
	"Build path specifies execution environment JavaSE-17.
	There are no JREs installed in the workspace that are strictly 	compatible with this environment. UO287577 Build path JRE System 	Library Problem"
Es un warning que salta o no dependiento de las JREs que se tengan
instaladas en el workspace y al cambiar de un eclipse a otro surge la
posibilidad de que aparezca el warning.
Es un warning bastante común pero quería asegurarme de decirles que es un
warning que está "fuera de mi alcance" porque depende del eclipse al que
será importado el proyecto más que del eclipse del que fue exportado.
