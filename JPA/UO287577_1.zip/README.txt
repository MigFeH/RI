Miguel Fernández Huerta
UO287577
Modelo 1

Consideraciones a la hora de evaluar:
La ejecución puede cascar si se piden acciones que no
corresponden con mi modelo (el 1) lanzando una NotYetImplementedException
(Ejemplo: las acciones que llamen a la interfaz de servicio SparePartReportService.
O la acción de generar pedidos).


Es posible que salte el warning:
	"Build path specifies execution environment JavaSE-17.
	There are no JREs installed in the workspace that are strictly 	compatible with this environment. UO287577 Build path JRE System 	Library Problem"
Es un warning que salta o no dependiento de las JREs que se tengan
instaladas en el workspace y al cambiar de un eclipse a otro surge la
posibilidad de que aparezca el warning.
Es un warning bastante común pero quería asegurarme de decirles que es un
warning que está "fuera de mi alcance" porque depende del eclipse al que
será importado el proyecto más que del eclipse del que fue exportado.
