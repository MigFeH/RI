package uo.ri.cws.domain;

import java.util.Objects;

import uo.ri.util.assertion.ArgumentChecks;

/**
 * This class is a Value Type, thus
 *    - no setters
 *	  - hashcode and equals over all attributes
 */
public class Address {
	private String street;
	private String city;
	private String zipCode;

	public Address(String calle, String ciudad, String codigo) {
		ArgumentChecks.isNotBlank(calle, "Invalid null or blank street");
		ArgumentChecks.isNotBlank(ciudad, "Invalid null or blank city");
		ArgumentChecks.isNotBlank(codigo, "Invalid null or blank zipCode");
		
		street = calle;
		city = ciudad;
		zipCode = codigo;
	}

	public String getStreet() {
		return street;
	}

	public String getCity() {
		return city;
	}

	public String getZipCode() {
		return zipCode;
	}

	@Override
	public int hashCode() {
		return Objects.hash(city, street, zipCode);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		return Objects.equals(city, other.city) 
		    && Objects.equals(street, other.street)
			&& Objects.equals(zipCode, other.zipCode);
	}

	@Override
	public String toString() {
		return "Address [street=" + street 
		    + ", city=" + city 
		    + ", zipCode=" + zipCode + "]";
	}
}
