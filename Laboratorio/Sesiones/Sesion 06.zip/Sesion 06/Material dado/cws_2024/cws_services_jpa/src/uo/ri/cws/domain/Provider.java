package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import uo.ri.util.assertion.ArgumentChecks;

public class Provider {
	
	// atributos naturales
	private String nif; // natural key (con esto hacemos el hashcode y equals)
	private String name;
	private String phone;
	private String email;
	
	// atributos accidentales
	private Set<Order> orders = new HashSet<>();
	private Set<Supply> supplies = new HashSet<>();
	
	public Provider(String nif, String name, String phone, String email) {
		ArgumentChecks.isNotBlank(nif, "Invalid null or blank nif");
		ArgumentChecks.isNotBlank(name, "Invalid null or blank name");
		ArgumentChecks.isNotBlank(phone, "Invalid null or blank phone");
		ArgumentChecks.isNotBlank(email, "Invalid null or blank email");
		this.nif = nif;
		this.name = name;
		this.phone = phone;
		this.email = email;
	}

	public Provider(String nif)
	{
		this(nif,"no-name","no-phone","no-email");
	}

	public String getNif() {
		return nif;
	}

	public String getName() {
		return name;
	}

	public String getPhone() {
		return phone;
	}

	public String getEmail() {
		return email;
	}

	public Set<Order> getOrders() {
		return new HashSet<>( orders );
	}
	
	Set<Order> _getOrders() {
		return this.orders;
	}

	public Set<Supply> getSupplies() {
		return new HashSet<>( supplies );
	}
	
	Set<Supply> _getSupplies() {
		return this.supplies;
	}

	@Override
	public int hashCode() {
		return Objects.hash(nif);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Provider other = (Provider) obj;
		return Objects.equals(nif, other.nif);
	}

	@Override
	public String toString() {
		return "Provider [nif=" + nif 
		    + ", name=" + name 
		    + ", phone=" + phone 
		    + ", email=" + email + "]";
	}
}
