package uo.ri.cws.domain;

import java.util.Objects;

import uo.ri.util.assertion.ArgumentChecks;

public class OrderLine {
	
	// atributos naturales
	private double price;
	private int quantity;
	
	// atributos accidentales
	private SparePart sparePart;

	public OrderLine(SparePart sparePart, double price, int quantity) {
		ArgumentChecks.isNotNull(sparePart,"Invalid null spare part");
		ArgumentChecks.isTrue(price >= 0.0,"Invalid negative price");
		ArgumentChecks.isTrue(quantity > 0,"Invalid negative or zero quantity");
		this.price = price;
		this.quantity = quantity;
		this.sparePart = sparePart;
	}

	public OrderLine(SparePart sparePart, double price) {
		this(sparePart,price,sparePart.getMaxStock()-sparePart.getStock());
	}

	public double getPrice() {
		return price;
	}

	public int getQuantity() {
		return quantity;
	}

	public SparePart getSparePart() {
		return sparePart;
	}
	
	public void receive() {
		sparePart.updatePriceAndStock(price,quantity);
	}

	public double getAmount() {
		return quantity * price;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(price, quantity, sparePart);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderLine other = (OrderLine) obj;
		return Double.doubleToLongBits(price) == 
		    Double.doubleToLongBits(other.price) 
		    && quantity == other.quantity
			&& Objects.equals(sparePart, other.sparePart);
	}

	@Override
	public String toString() {
		return "OrderLine [price=" + price 
		    + ", quantity=" + quantity 
		    + ", sparePart=" + sparePart + "]";
	}
}
