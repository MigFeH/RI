package uo.ri.cws.domain;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import uo.ri.util.assertion.ArgumentChecks;
import uo.ri.util.assertion.StateChecks;
import uo.ri.util.math.Round;

public class Invoice {
	public enum InvoiceState { NOT_YET_PAID, PAID }

	// natural attributes
	private Long number; // natural key (con esto se hace el hashcode y equals)
	private LocalDate date;
	private double amount;
	private double vat;
	private InvoiceState state = InvoiceState.NOT_YET_PAID;
	
	// accidental attributes
	private Set<WorkOrder> workOrders = new HashSet<>();
	private Set<Charge> charges = new HashSet<>();
	
	// full constructor
    public Invoice(Long number, LocalDate date, List<WorkOrder> workOrders) {
        ArgumentChecks.isNotNull(number, "Invalid null number");
        ArgumentChecks.isNotNull(date, "Invalid null date");
        ArgumentChecks.isNotNull(workOrders, "Invalid null list");
        ArgumentChecks.isTrue(number >= 0, "Invalid number under zero");
        
        // store the number
        this.number = number;
        // store a copy of the date
        this.date = date;
        // add every work order calling addWorkOrder( w )
        for(WorkOrder wo : workOrders)
        {
            addWorkOrder(wo);
        }
    }

	public Invoice(Long number) {
		// call full constructor with sensible defaults
		this(number,LocalDate.now(),List.of());
	}

	public Invoice(Long number, LocalDate date) {
		// call full constructor with sensible defaults
		this(number,date,List.of());
	}

	public Invoice(Long number, List<WorkOrder> workOrders) {
		this(number, LocalDate.now(), workOrders);
	}

	/**
	 * Computes amount and vat (vat depends on the date)
	 */
	private void computeAmount() {
		double nuevoAmount = 0.0;
		for(WorkOrder wo : workOrders)
		{
			nuevoAmount += wo.getAmount();
		}
		this.amount = Round.twoCents(nuevoAmount * (1 + (getVat() / 100)));
	}

	/**
	 * Adds (double links) the workOrder to the invoice 
	 * and updates the amount and vat
	 * @param workOrder
	 * @see UML_State diagrams on the problem statement document
	 * @throws IllegalStateException if the invoice status is not NOT_YET_PAID
	 */
	public void addWorkOrder(WorkOrder workOrder) {
		StateChecks.isTrue(isNotSettled(), "The invoice is settled");
		StateChecks.isTrue(workOrder.isFinished(), "Workorder is not finished");
		
		Associations.Bill.link(this, workOrder);
		workOrder.markAsInvoiced();
		computeAmount();
	}

	/**
	 * Removes a work order from the invoice and recomputes amount and vat
	 * @param workOrder
	 * @see UML_State diagrams on the problem statement document
	 * @throws IllegalStateException if the invoice status is not NOT_YET_PAID
	 */
	public void removeWorkOrder(WorkOrder workOrder) {
		StateChecks.isTrue(isNotSettled(), 
		    "The invoice status is not NOT_YET_PAID");
		
		Associations.Bill.unlink(this, workOrder);
		workOrder.markBackToFinished();
		computeAmount();
	}

	/**
	 * Marks the invoice as PAID, but
	 * @throws IllegalStateException if
	 * 	- Is already settled
	 *  - Or the amounts paid with charges to payment means do not cover
	 *  	the total of the invoice
	 */
	public void settle() {
	    StateChecks.isTrue(isNotSettled(), 
	        "The invoice status is already PAID");
	    double totalAccumulated = 0.0;
	    for(Charge charg : charges)
	    {
	        totalAccumulated += charg.getAmount();
	    }
	    StateChecks.isTrue(totalAccumulated >= amount,
	        "The amounts paid with charges to payment means do not cover the "
	        + "total of the invoice");
	    state = InvoiceState.PAID;
	}

	public Set<WorkOrder> getWorkOrders() {
		return new HashSet<>( workOrders );
	}

	Set<WorkOrder> _getWorkOrders() {
		return workOrders;
	}

	public Set<Charge> getCharges() {
		return new HashSet<>( charges );
	}

	Set<Charge> _getCharges() {
		return charges;
	}

	public Long getNumber() {
		return number;
	}

	public LocalDate getDate() {
		return date;
	}

	public double getAmount() {
		return amount;
	}

	public double getVat() {
		vat = LocalDate.parse("2012-07-01").isAfter(date) ? 18.0 : 21.0;
		return vat;
	}
	
	public boolean isSettled() {
		return InvoiceState.PAID.equals(state);
	}
	
	public boolean isNotSettled() {
		return InvoiceState.NOT_YET_PAID.equals(state);
	}

	@Override
	public int hashCode() {
		return Objects.hash(number);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Invoice other = (Invoice) obj;
		return Objects.equals(number, other.number);
	}

	@Override
	public String toString() {
		return "Invoice [number=" + number 
		    + ", date=" + date 
		    + ", amount=" + amount 
		    + ", vat=" + vat 
		    + ", state=" + state + "]";
	}
}
