package uo.ri.cws.domain;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import uo.ri.util.assertion.ArgumentChecks;
import uo.ri.util.assertion.StateChecks;

public class Order {
	public enum OrderState {
		PENDING,
		RECEIVED
	}
	
	// atributos naturales
	private String code; //natural key(con esto hacemos el hashcode y el equals)
	private LocalDate orderedDate;
	private double amount = 0.0;
	private LocalDate receptionDate;
	private OrderState state = OrderState.PENDING;
	
	// atributos accidentales
	private Provider provider;
	private Set<OrderLine> lines = new HashSet<>();
	
	public Order(String code, LocalDate orderedDate, 
	    double amount, LocalDate receptionDate, OrderState state) {
		ArgumentChecks.isNotBlank(code, "Invalid null or blank code");
		ArgumentChecks.isNotNull(orderedDate, "Invalid null ordered date");
		ArgumentChecks.isTrue(amount >= 0.0, "Invalid negative amount");
		ArgumentChecks.isNotNull(state, "Invalid null state");
		this.code = code;
		this.orderedDate = orderedDate;
		this.amount = amount;
		this.receptionDate = receptionDate;
		this.state = state;
	}

	public Order(String code) {
		this(code,LocalDate.now(),0.0,null,OrderState.PENDING);
	}
	
	void _setProvider(Provider provider) {
		this.provider = provider;
	}

	public Set<OrderLine> getLines() {
		return new HashSet<>( lines );
	}

	public String getCode() {
		return code;
	}

	public LocalDate getOrderedDate() {
		return orderedDate;
	}

	public double getAmount() {
		return amount;
	}

	public LocalDate getReceptionDate() {
		return receptionDate;
	}

	public OrderState getState() {
		return state;
	}

	public Provider getProvider() {
		return provider;
	}
	
	public Set<OrderLine> getOrderLines() {
		return new HashSet<>( lines );
	}
	
	public boolean isReceived() {
		return OrderState.RECEIVED.equals(state);
	}
	
	public boolean isPending() {
		return OrderState.PENDING.equals(state);
	}

	@Override
	public int hashCode() {
		return Objects.hash(code);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		return Objects.equals(code, other.code);
	}

	@Override
	public String toString() {
		return "Order [code=" + code 
		    + ", orderedDate=" + orderedDate 
		    + ", amount=" + amount 
		    + ", receptionDate=" + receptionDate 
		    + ", state=" + state + "]";
	}

	public void addSparePartFromSupply(Supply supp) {
		ArgumentChecks.isNotNull(supp, "Invalid null supply");
		for(OrderLine line : lines)
		{
			StateChecks.isFalse(line.getSparePart().equals(supp.getSparePart()), 
			    "The spare part is already added to the order");
		}
		if(supp.getSparePart().getStock() < supp.getSparePart().getMinStock())
		{			
			state = OrderState.PENDING;
			lines.add(new OrderLine(supp.getSparePart(),supp.getPrice()));
			actualizarAmount();
		}
	}

	public void receive() {
		StateChecks.isTrue(isPending(), "Order already received");
		for(OrderLine line : lines)
		{
			line.receive();
		}
		state = OrderState.RECEIVED;
		receptionDate = LocalDate.now();
	}

	public void removeSparePart(SparePart sp) {
		ArgumentChecks.isNotNull(sp, "Invalid null spare part");
		for(OrderLine line : lines)
		{
			if(line.getSparePart().equals(sp))
			{
				lines.remove(line);
				actualizarAmount();
				return;
			}
		}
	}
	
	private void actualizarAmount() {
		double nuevoAmount = 0.0;
		for(OrderLine line : lines)
		{
			nuevoAmount += line.getAmount();
		}
		amount = nuevoAmount;
	}
}
