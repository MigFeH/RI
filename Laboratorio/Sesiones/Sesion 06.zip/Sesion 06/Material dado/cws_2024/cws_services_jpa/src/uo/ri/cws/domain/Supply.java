package uo.ri.cws.domain;

import java.util.Objects;

import uo.ri.util.assertion.ArgumentChecks;

public class Supply {
	
	// atributos naturales
	private int deliveryTerm;
	private double price;
	
	// atributos accidentales (clave)
	private Provider provider;
	private SparePart sparePart;

	public Supply(Provider provider, SparePart sparePart, double price, 
	    int deliveryTerm) {
		ArgumentChecks.isNotNull(provider,"Invalid null provider");
		ArgumentChecks.isNotNull(sparePart,"Invalid null spare part");
		ArgumentChecks.isTrue(price >= 0.0,"Invalid negative or zero price");
		ArgumentChecks.isTrue(deliveryTerm >= 0.0,
		    "Invalid negative or zero delivery term");
		this.price = price;
		this.deliveryTerm = deliveryTerm;
		Associations.Supply.link(provider,this,sparePart);
	}

	void _setProvider(Provider provider) {
		this.provider = provider;	
	}

	void _setSparePart(SparePart sparePart) {
		this.sparePart = sparePart;
	}

	public Provider getProvider() {
		return this.provider;
	}

	public SparePart getSparePart() {
		return this.sparePart;
	}

	public int getDeliveryTerm() {
		return deliveryTerm;
	}

	public double getPrice() {
		return price;
	}

	@Override
	public int hashCode() {
		return Objects.hash(provider, sparePart);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Supply other = (Supply) obj;
		return Objects.equals(provider, other.provider) 
		    && Objects.equals(sparePart, other.sparePart);
	}

	@Override
	public String toString() {
		return "Supply [deliveryTerm=" + deliveryTerm 
		    + ", price=" + price 
		    + ", provider=" + provider 
		    + ", sparePart=" + sparePart + "]";
	}
}
