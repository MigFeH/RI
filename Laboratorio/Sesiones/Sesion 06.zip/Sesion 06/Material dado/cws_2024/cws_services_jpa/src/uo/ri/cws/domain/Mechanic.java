package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import uo.ri.util.assertion.ArgumentChecks;

public class Mechanic {
	// natural attributes
	private String nif; // natural key (con esto se hace el hashcode y equals)
	private String surname;
	private String name;
	
	
	// accidental attributes
	private Set<WorkOrder> assigned = new HashSet<>();
	private Set<Intervention> interventions = new HashSet<>();


	public Mechanic(String nif, String nombre, String apellidos) {
		ArgumentChecks.isNotBlank(nif, "Imvalid null or blanck nif");
		ArgumentChecks.isNotBlank(nif, apellidos);
		ArgumentChecks.isNotBlank(nif, apellidos);
		
		this.nif = nif;
		this.name = nombre;
		this.surname = apellidos;
	}
	

	public Mechanic(String nif)
	{
		this(nif,"no-name","no-surname");
	}


	public Set<WorkOrder> getAssigned() {
		return new HashSet<>( assigned );
	}

	Set<WorkOrder> _getAssigned() {
		return assigned;
	}

	public Set<Intervention> getInterventions() {
		return new HashSet<>( interventions );
	}

	Set<Intervention> _getInterventions() {
		return interventions;
	}


	@Override
	public int hashCode() {
		return Objects.hash(nif);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Mechanic other = (Mechanic) obj;
		return Objects.equals(nif, other.nif);
	}


	@Override
	public String toString() {
		return "Mechanic [nif=" + nif 
		    + ", surname=" + surname 
		    + ", name=" + name + "]";
	}
}
