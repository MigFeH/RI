package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import uo.ri.util.assertion.ArgumentChecks;

public class SparePart {
	// natural attributes
	private String code; // clave natural(con esto se hace el hashcode y equals)
	private String description;
	private double price;
	private int stock;
	private int minStock;
	private int maxStock;

	// accidental attributes
	private Set<Substitution> substitutions = new HashSet<>();
	private Set<Supply> supplies = new HashSet<>();

	public SparePart(String code, String description, double price, int stock, 
	    int minStock, int maxStock) {
		ArgumentChecks.isNotBlank(code, "Invalid null or blank code");
		ArgumentChecks.isNotBlank(description, 
		    "Invalid null or blank description");
		ArgumentChecks.isTrue(price >= 0.0, "Invalid negative price");
		ArgumentChecks.isTrue(stock >= 0, "Invalid negative stock");
		ArgumentChecks.isTrue(minStock >= 0, 
		    "Invalid negative min stock");
		ArgumentChecks.isTrue(maxStock >= 0, 
		    "Invalid negative max stock");
		this.code = code;
		this.description = description;
		this.price = price;
		this.stock = stock;
		this.minStock = minStock;
		this.maxStock = maxStock;
	}
	
	public SparePart(String code, String description, double price) {
		this(code,description,price,2,1,5);
	}

	public SparePart(String code) { 
		this(code,"no-desc",0.0,2,1,5);
	}
	
	public void setMinStock(int i) {
		this.minStock = i;
	}

	public void setMaxStock(int i) {
		this.maxStock = i;
	}

	public Set<Substitution> getSubstitutions() {
		return new HashSet<>( substitutions );
	}

	Set<Substitution> _getSubstitutions() {
		return substitutions;
	}
	
	Set<Supply> _getSupplies() {
		return this.supplies;
	}

	public String getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}

	public double getPrice() {
		return price;
	}
	
	public int getMaxStock() {
		return this.maxStock;
	}
	
	public int getStock() {
		return stock;
	}

	public int getMinStock() {
		return minStock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
	
	public Set<Supply> getSupplies() {
		return new HashSet<>( supplies );
	}

	public void updatePriceAndStock(double nuevoPrecio, int nuevaCantidad) {
		ArgumentChecks.isTrue(nuevaCantidad > 0, "Invalid zero or negative new quantity");
		ArgumentChecks.isTrue(nuevoPrecio >= 0.0, "Invalid negative new price");
		
		
		int expectedStock = this.stock + nuevaCantidad;
		double expectedPrice = (
					this.stock * this.price
					+ nuevaCantidad * nuevoPrecio * 1.2
				)
				/ expectedStock;
		
		
		this.price = expectedPrice;
		this.stock += nuevaCantidad;
	}
	
	public int getTotalUnitsSold() {
		int res = 0;
		for(Substitution sub : substitutions)
		{
			res += sub.getQuantity();
		}
		return res;
	}

	@Override
	public int hashCode() {
		return Objects.hash(code);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SparePart other = (SparePart) obj;
		return Objects.equals(code, other.code);
	}

	@Override
	public String toString() {
		return "SparePart [code=" + code + ", description=" + description + ", price=" + price + ", stock=" + stock
				+ ", minStock=" + minStock + ", maxStock=" + maxStock + "]";
	}

	public int getQuantityToOrder() {
		if(stock < minStock)
		{
			return maxStock - stock;
		} 
		return 0;
	}
}
