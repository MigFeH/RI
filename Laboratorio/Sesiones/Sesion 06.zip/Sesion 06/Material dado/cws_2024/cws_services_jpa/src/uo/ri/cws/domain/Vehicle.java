package uo.ri.cws.domain;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import uo.ri.util.assertion.ArgumentChecks;

public class Vehicle {
	private String plateNumber; // natural key 
	//                             (con esto se hace el hashcode y equals)
	private String make;
	private String model;
	
	// Atributos accidentales
	private Client client;
	private VehicleType type;
	private Set<WorkOrder> workOrders = new HashSet<>(); // para la relacion fix
	
	public Vehicle(String plateNumber, String make, String model) {
		ArgumentChecks.isNotBlank(plateNumber, 
		    "Invalid null or blank plateNumber");
		ArgumentChecks.isNotBlank(make, "Invalid null or blank make");
		ArgumentChecks.isNotBlank(model, "Invalid null or blank model");
		
		this.plateNumber = plateNumber;
		this.make = make;
		this.model = model;
	}

	public Vehicle(String plateNumber) {
		this(plateNumber,"no-make","no-model");
	}

	public String getPlateNumber() {
		return plateNumber;
	}

	public String getMake() {
		return make;
	}

	public String getModel() {
		return model;
	}
	
	public Client getClient() {
		return client;
	}
	
	public VehicleType getVehicleType() {
		return type;
	}
	
	public Set<WorkOrder> getWorkOrders() {
		return new HashSet<>( workOrders );
	}

    Set<WorkOrder> _getWorkOrders() {
        return this.workOrders;
    }
	
	/*package*/ void _setClient(Client client) {
		this.client = client;
	}
	
	/*package*/ void _setVehicleType(VehicleType type) {
		this.type = type;
	}

	@Override
	public int hashCode() {
		return Objects.hash(plateNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vehicle other = (Vehicle) obj;
		return Objects.equals(plateNumber, other.plateNumber);
	}

	@Override
	public String toString() {
		return "Vehicle [plateNumber=" + plateNumber 
		    + ", make=" + make 
		    + ", model=" + model + "]";
	}
}
