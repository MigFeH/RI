package uo.ri.cws.domain;

public class Associations {

	public static class Own {

		public static void link(Client client, Vehicle vehicle) {
			vehicle._setClient(client);
			client._getVehicles().add(vehicle);
		}

		public static void unlink(Client cliente, Vehicle vehicle) {
			cliente._getVehicles().remove(vehicle);
			vehicle._setClient(null);
		}

	}

	public static class Classify {

		public static void link(VehicleType vehicleType, Vehicle vehicle) {
			vehicle._setVehicleType(vehicleType);
			vehicleType._getVehicles().add(vehicle);
		}

		public static void unlink(VehicleType tipoVehicle, Vehicle vehicle) {
			tipoVehicle._getVehicles().remove(vehicle);
			vehicle._setVehicleType(null);
		}
	}

	public static class Hold {

		public static void link(PaymentMean mean, Client client) {
			mean._setClient(client);
			client._getPaymentMeans().add(mean);
		}

		public static void unlink(Client client, PaymentMean mean) {
			client._getPaymentMeans().remove(mean);
			mean._setClient(null);
		}
	}

	public static class Fix {

		public static void link(Vehicle vehicle, WorkOrder workOrder) {
			// lado 1
			workOrder._setVehicle(vehicle);
			// lado muchos
			vehicle._getWorkOrders().add(workOrder);
		}

		public static void unlink(Vehicle vehicle, WorkOrder workOrder) {
			// lado muchos
			vehicle._getWorkOrders().remove(workOrder);
			// lado 1
			workOrder._setVehicle(null);
		}
	}

	public static class Bill {

		public static void link(Invoice invoice, WorkOrder workOrder) {
			// lado 1
			workOrder._setInvoice(invoice);
			// lado muchos
			invoice._getWorkOrders().add(workOrder);
		}

		public static void unlink(Invoice invoice, WorkOrder workOrder) {
			// lado muchos
			invoice._getWorkOrders().remove(workOrder);
			// lado 1
			workOrder._setInvoice(null);
		}
	}

	public static class Settle {

		public static void link(Invoice invoice, Charge cargo, PaymentMean mp) {
			// lado 1
			cargo._setInvoice(invoice);
			cargo._setPaymentMean(mp);
			// lado muchos
			invoice._getCharges().add(cargo);
			mp._getCharges().add(cargo);
		}

		public static void unlink(Charge cargo) {
			// lado muchos
			cargo.getInvoice()._getCharges().remove(cargo);
			cargo.getPaymentMean()._getCharges().remove(cargo);
			// lado 1
			cargo._setInvoice(null);
			cargo._setPaymentMean(null);
		}
	}

	public static class Assign {

		public static void link(Mechanic mechanic, WorkOrder workOrder) {
			// lado 1
			workOrder._setMechanic(mechanic);
			// lado muchos
			mechanic._getAssigned().add(workOrder);
		}

		public static void unlink(Mechanic mechanic, WorkOrder workOrder) {
			// lado muchos
			mechanic._getAssigned().remove(workOrder);
			// lado 1
			workOrder._setMechanic(null);
		}
	}

	public static class Intervene {

		public static void link(WorkOrder workOrder,
				Intervention intervention, Mechanic mechanic) {
			intervention._setWorkOrder(workOrder);
			intervention._setMechanic(mechanic);
			mechanic._getInterventions().add(intervention);
			workOrder._getInterventions().add(intervention);
		}

		public static void unlink(Intervention intervention) {
			intervention.getMechanic()._getInterventions()
			.remove(intervention);
			intervention.getWorkOrder()._getInterventions()
			.remove(intervention);
			intervention._setMechanic(null);
			intervention._setWorkOrder(null);
		}
	}

	public static class Substitute {

		static void link(SparePart sparePart, Substitution substitution,
				Intervention intervention) {
			substitution._setIntervention(intervention);
			substitution._setSparePart(sparePart);
			sparePart._getSubstitutions().add(substitution);
			intervention._getSubstitutions().add(substitution);
		}

		public static void unlink(Substitution substitution) {
			substitution.getIntervention()._getSubstitutions()
			.remove(substitution);
			substitution.getSparePart()._getSubstitutions()
			.remove(substitution);
			substitution._setIntervention(null);
			substitution._setSparePart(null);
		}
	}

	public static class Supply {
		public static void link(Provider provider, 
		    uo.ri.cws.domain.Supply supply, SparePart sparePart) {
			// lado 1
			supply._setProvider(provider);
			supply._setSparePart(sparePart);
			// lado muchos
			provider._getSupplies().add(supply);
			sparePart._getSupplies().add(supply);
		}

		public static void unlink(uo.ri.cws.domain.Supply supply) {
			// lado muchos
			supply.getProvider()._getSupplies().remove(supply);
			supply.getSparePart()._getSupplies().remove(supply);
			// lado 1
			supply._setProvider(null);
			supply._setSparePart(null);
		}
	}

	public static class Deliver {
		public static void link(Provider provider, Order order) {
			// lado 1
			order._setProvider(provider);
			// lado muchos
			provider._getOrders().add(order);
		}

		public static void unlink(Provider provider, Order order) {
			// lado muchos
			provider._getOrders().remove(order);
			// lado 1
			order._setProvider(null);
		}
	}
}
