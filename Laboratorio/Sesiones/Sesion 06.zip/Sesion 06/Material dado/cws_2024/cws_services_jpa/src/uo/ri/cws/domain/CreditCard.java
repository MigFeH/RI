package uo.ri.cws.domain;

import java.time.LocalDate;
import java.util.Objects;

import uo.ri.util.assertion.ArgumentChecks;
import uo.ri.util.assertion.StateChecks;

public class CreditCard extends PaymentMean {
	private String number; // natural key(con esto se hace el hashcode y equals)
	private String type;
	private LocalDate validThru;
	
	
	public CreditCard(String number, String type, LocalDate validThru) {
		ArgumentChecks.isNotBlank(number, "Invalid null or blank number");
		ArgumentChecks.isNotBlank(type, "Invalid null or blank type");
		ArgumentChecks.isNotNull(validThru, "Invalid valid thru");
		this.number = number;
		this.type = type;
		this.validThru = validThru;
	}


	@Override
	public boolean canPay(Double amount) {
		StateChecks.isTrue(validThru.isAfter(LocalDate.now()), 
		    "The card is expired");
		return true;
	}


	public String getNumber() {
		return number;
	}


	public String getType() {
		return type;
	}


	public LocalDate getValidThru() {
		return validThru;
	}


	@Override
	public int hashCode() {
		return Objects.hash(number);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CreditCard other = (CreditCard) obj;
		return Objects.equals(number, other.number);
	}

	@Override
	public String toString() {
		return "CreditCard [number=" + number 
		    + ", type=" + type 
		    + ", validThru=" + validThru + "]";
	}
	
	

}
