package uo.ri.cws.domain;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import uo.ri.util.assertion.ArgumentChecks;

public class Intervention {
	// natural attributes
	private LocalDateTime date; // natural key 
	//                             (se hace con esto el hashcode y equals)
	private int minutes;
	//private double amount; // propiedad calculada

	// accidental attributes
	private WorkOrder workOrder; // natural key 
	//                             (se hace con esto el hashcode y equals)
	private Mechanic mechanic; // natural key 
	//                             (se hace con esto el hashcode y equals)
	private Set<Substitution> substitutions = new HashSet<>();

    public Intervention(Mechanic mechanic, WorkOrder workOrder, 
	    LocalDateTime date, int minutes) {
		ArgumentChecks.isNotNull(mechanic, "Invalid null mechanic");
		ArgumentChecks.isNotNull(workOrder, "Invalid null work order");
		ArgumentChecks.isNotNull(date, "Invalid null date");
		ArgumentChecks.isTrue(minutes >= 0, "Invalid negative minutes");
		this.date = date.truncatedTo(ChronoUnit.MILLIS);
		this.minutes = minutes;
		
		/*
		 * this.workOrder = workOrder;
		 * this.mechanic = mechanic;
		 * 
		 * MAL -> La asociacion se realiza con Associations
		 * MAL -> Aqui faltaria incluir esta intervencion en la lista de
		 * intervenciones del mecanico y de la workorder
		 */
		Associations.Intervene.link(workOrder, this, mechanic);
	}

	public Intervention(Mechanic mechanic, WorkOrder workOrder, int minutos) {
        this(mechanic,workOrder,LocalDateTime.now(),minutos);
    }

	public LocalDateTime getDate() {
		return date;
	}

	public int getMinutes() {
		return minutes;
	}

	public WorkOrder getWorkOrder() {
		return workOrder;
	}

	public Mechanic getMechanic() {
		return mechanic;
	}

	public double getAmount() {
		double precioPorMinuto = workOrder
		    .getVehicle()
		    .getVehicleType()
		    .getPricePerHour() / 60;
		double importeManoDeObra = minutes * precioPorMinuto;
		
		double importeRepuestos = 0.0;
		for(Substitution sub : substitutions)
		{
			importeRepuestos += sub.getAmount();
		}
		
		return importeManoDeObra + importeRepuestos;
	}

	void _setWorkOrder(WorkOrder workOrder) {
		this.workOrder = workOrder;
	}

	void _setMechanic(Mechanic mechanic) {
		this.mechanic = mechanic;
	}

	public Set<Substitution> getSubstitutions() {
		return new HashSet<>( substitutions );
	}

	Set<Substitution> _getSubstitutions() {
		return substitutions;
	}

	@Override
	public int hashCode() {
		return Objects.hash(date, mechanic, workOrder);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Intervention other = (Intervention) obj;
		return Objects.equals(date, other.date) 
		    && Objects.equals(mechanic, other.mechanic)
			&& Objects.equals(workOrder, other.workOrder);
	}

	@Override
	public String toString() {
		return "Intervention [date=" + date 
		    + ", minutes=" + minutes 
		    + ", workOrder=" + workOrder 
		    + ", mechanic=" + mechanic + "]";
	}

	
}
